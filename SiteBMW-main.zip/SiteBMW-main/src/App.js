import "bootstrap/dist/css/bootstrap.min.css";
import AppRoutes from "./routes/AppRoutes";
export default function App() {
  return <AppRoutes />;
}
